/** 
 * Task B will Execute After Task A 
 * Using Promise to set TimeOut
 */

console.log("| Task Execution Started |")

async function TaskA(){
    console.log("| Task 1 is Executed |")

}

async function TaskB(){
    let result ;
    result = await print();
    console.log(result)
}

async function print(){
    await timeout(600000); // 600000 = 10min (1000 = 1sec)
    return "| Task B executed After 10 min |"
}

function timeout(duration){
    return new Promise(resolve => setTimeout(resolve , duration))
}

TaskA();
TaskB();