const express = require('express');
const connection = require('../connection');
const router = express.Router();
router.postr('/create',(reeq,res,next)=>{
    let product = req.body;
})
module.exports=routers;