CREATE TABLE product(
    id int NOT NULL AUTO_INCREMENT,
name varchar(255) NOT NULL,

)